/*
 * Copyright (c) 2007 Hewlett-Packard Development Company, L.P.
 * Contributed by Stephane Eranian <eranian@hpl.hp.com>
 *
 * This file should never be included directly, use
 * <perfmon/perfmon.h> instead.
 */

#ifndef _PERFMON_X86_64_H_
#define _PERFMON_X86_64_H_

#include <perfmon/perfmon_i386.h>

#endif /* _PERFMON_X86_64_H_ */
