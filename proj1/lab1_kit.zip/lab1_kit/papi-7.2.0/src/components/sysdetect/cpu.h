#ifndef __CPU_H__
#define __CPU_H__

void open_cpu_dev_type( _sysdetect_dev_type_info_t *dev_type_info );
void close_cpu_dev_type( _sysdetect_dev_type_info_t *dev_type_info );

#endif /* End of __CPU_H__ */
