# PERF\_EVENT Component

The PERF\_EVENT component enables PAPI to access perf\_event CPU counters.

* [Enabling the PERF\_EVENT Component](#enabling-the-perf_event-component)

***
## Enabling the PERF\_EVENT Component

This component is enabled by default.

Typically, the utility `papi_components_avail` (available in
`papi/src/utils/papi_components_avail`) will display the components available
to the user, and whether they are disabled, and when they are disabled why.
