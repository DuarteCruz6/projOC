char *get_uncore_event(char *event, int size);
char *get_uncore_cbox_event(char *event_name, char *uncore_base, int size);
